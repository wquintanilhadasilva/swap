export default function (options: {
    testing?: boolean;
    cliArgs: string[];
}): Promise<number>;
